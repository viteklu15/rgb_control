import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class RgbService {
  /// Вызывается при изменении цвета на кольце.
  static void onColorChanged(Color c, {required bool isOn}) {
    final r = c.red, g = c.green, b = c.blue;
    debugPrint('[RGB] color changed: R=$r G=$g B=$b | isOn=$isOn');
    // TODO: здесь отправьте цвет на ваше устройство (BLE/HTTP/UDP)
  }

  /// Вызывается при нажатии кнопки питания.
  static void onPowerToggled(bool isOn, {Color? current}) {
    final c = current ?? const Color(0xFF000000);
    debugPrint('[RGB] power ${isOn ? 'ON' : 'OFF'} | R=${c.red} G=${c.green} B=${c.blue}');
    // TODO: здесь отправьте команду питания
  }

  /// Режим «мигалка».
  static void onPoliceMode(bool enabled) {
    debugPrint('[MODE] police=${enabled ? 1 : 0}');
    // TODO: отправить флаг режима
  }

  /// Режим «автоцвет».
  static void onAutoColor(bool enabled) {
    debugPrint('[MODE] autoColor=${enabled ? 1 : 0}');
    // TODO: отправить флаг режима
  }
}
