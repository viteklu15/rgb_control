import 'package:flutter/material.dart';
import 'ui/demo_ring_screen.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: DemoRingScreen(),
  ));
}
